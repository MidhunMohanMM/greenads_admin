import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-report',
  templateUrl: './sms-report.component.html',
  styleUrls: ['./sms-report.component.css']
})
export class SmsReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
