import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plugin-apis',
  templateUrl: './plugin-apis.component.html',
  styleUrls: ['./plugin-apis.component.css']
})
export class PluginApisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
