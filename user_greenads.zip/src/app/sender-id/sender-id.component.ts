import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sender-id',
  templateUrl: './sender-id.component.html',
  styleUrls: ['./sender-id.component.css']
})
export class SenderIdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
