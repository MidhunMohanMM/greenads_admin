import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-download-center',
  templateUrl: './download-center.component.html',
  styleUrls: ['./download-center.component.css']
})
export class DownloadCenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
