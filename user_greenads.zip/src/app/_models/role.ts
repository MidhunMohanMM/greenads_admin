﻿export enum Role {
    USR = 'USR',
    RUSR = 'RUSR',
    SUBUSR = 'SUBUSR'
}