import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-blnc',
  templateUrl: './account-blnc.component.html',
  styleUrls: ['./account-blnc.component.css']
})
export class AccountBlncComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
